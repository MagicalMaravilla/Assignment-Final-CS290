document.addEventListener('DOMContentLoaded', function() {
    var mealTimeRadios = document.querySelectorAll('.meal-preference input[type="radio"]');

    // Function to clear all highlights
    function clearHighlights() {
        document.querySelectorAll('.meal-preference label').forEach(function(label) {
            label.classList.remove('highlighted', 'breakfast', 'lunch', 'dinner', 'dessert');
        });
    }

    // Loop through all radio inputs to add change event listeners
    mealTimeRadios.forEach(function(radio) {
        radio.addEventListener('change', function() {
            // Clear existing highlights before applying new ones
            clearHighlights();

            // Add the highlighted class to the clicked radio's label
            if(radio.checked) {
                var label = radio.parentNode;
                label.classList.add('highlighted', radio.value);
            }
        });
    });
});
