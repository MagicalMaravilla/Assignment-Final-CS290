const express = require('express');
const path = require('path');

const app = express();
const port = 3000; // You can use any port that's free on your system

// Serve static files from a specific directory (e.g., 'public')
app.use(express.static('public'));

// Redirect root to your recipe home page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '/public/recipe_home_page.html'));
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
