document.getElementById('login-form').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent the default form submission behavior

    // Getting values from the form inputs
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Sending the sign-in request to the server
    try {
        const response = await fetch('/sign-in', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        });

        const data = await response.text();
        if (data === 'Sign-in successful.') {
            window.location.href = '/profile_page.html'; // Redirecting to the profile page
        } else {
            alert(data); // Show error message
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during login. Please try again.');
    }
});